<?php
// Konfigurasi database
$host = "localhost"; // atau IP server Anda
$username = "root"; // username untuk database
$password = ""; // password untuk database
$database = "restorankorea"; // nama database

// Membuat koneksi
$conn = new mysqli($host, $username, $password, $database);

// Mengecek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

echo "Koneksi berhasil!";
?>
