<p align="center">
<img align="center" src="http://ForTheBadge.com/images/badges/built-with-love.svg"> <img align="center" src="http://ForTheBadge.com/images/badges/uses-html.svg"> <img align="center" src="http://ForTheBadge.com/images/badges/makes-people-smile.svg"> <img align="center" src="http://ForTheBadge.com/images/badges/built-by-developers.svg">
</p>

# Aplikasi Restoran Web 
Aplikasi Restoran Web adalah sebuah aplikasi berbasis web yang dibuat untuk membantu pemilik restoran dalam mengelola bisnis mereka. Aplikasi ini dapat digunakan untuk menerima pesanan, mengatur stok makanan, memantau inventaris, mengelola keuangan, dan melakukan berbagai tugas penting lainnya yang terkait dengan pengelolaan restoran.

## 🧑 Pemilik

| Profile | Keterangan  |
|---------|--------------|
| Nama    | MUHAMAD RIFQI ASHARI |
| Sekolah | SMK PRESTASI PRIMA |
| Jurusan | REKAYASA PERANGKAT LUNAK |

 
## Ringkasan

Terdapat 2 level untuk pengguna:
- Level 1: Admin
- Level 2: User


**** Untuk Admin ****<br/>
username : admin <br/>
password : admin

**** Untuk User ****<br/>
username : user <br/>
password : user

<h3>Preview Aplikasi Aplikasi Restoran Web</h3>
<p>Tampilan Login Aplikasi Restoran</p>
<img src="https://github.com/MuhamadRifqiAshari/Aplikasi-Restoran-Web-Versi-Ke3/blob/main/Dokumentasi/Tampilan%20Login.png">

<p>Tampilan Register</p>
<img src="https://github.com/MuhamadRifqiAshari/Aplikasi-Restoran-Web-Versi-Ke3/blob/main/Dokumentasi/Tampilan%20Register.png">

<p>Tampilan Admin</p>
<img src="https://github.com/MuhamadRifqiAshari/Aplikasi-Restoran-Web-Versi-Ke3/blob/main/Dokumentasi/Tampilan%20Admin.png">

<p>Tampilan User</p>
<img src="https://github.com/MuhamadRifqiAshari/Aplikasi-Restoran-Web-Versi-Ke3/blob/main/Dokumentasi/Tampilan%20User.png">
